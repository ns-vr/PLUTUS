# PLUTUS Architecture

## Risk Engine Weights
| Agent     | CPI Weight |
|-----------|-----------|
| Finance   | 35%       |
| Health    | 30%       |
| Insurance | 20%       |
| Fraud     | 15%       |
