"""
Insurance Agent
---------------
Evaluates insurance policy documents to identify coverage gaps,
claim readiness, and financial exposure from underinsurance.
"""

from crewai import Agent, Task, Crew
from langchain_openai import ChatOpenAI


llm = ChatOpenAI(model="gpt-4o", temperature=0.2)


def create_insurance_agent() -> Agent:
    return Agent(
        role="Insurance Coverage Analyst",
        goal=(
            "Review insurance policies to find coverage gaps, exclusions, and "
            "scenarios where the user would be financially exposed despite "
            "believing they are protected."
        ),
        backstory=(
            "You are an independent insurance broker and certified financial "
            "planner who has reviewed thousands of policies. You know exactly "
            "which fine print clauses leave people unprotected."
        ),
        llm=llm,
        verbose=True,
    )


def analyze_insurance_documents(document_text: str) -> dict:
    """
    Run the insurance agent on policy document text.
    Returns gap analysis and risk score.
    """
    agent = create_insurance_agent()

    task = Task(
        description=f"""
        Analyze the following insurance policy document and return a JSON object with:
        - gap_score: integer 0–100 (100 = most exposed / most gaps)
        - coverage_gaps: list of identified gaps or exclusions
        - max_out_of_pocket_exposure: estimated dollar amount ($)
        - claim_readiness: "high" | "medium" | "low"
        - recommendation: one-sentence action item

        Document:
        {document_text}
        """,
        agent=agent,
        expected_output="JSON with gap_score, coverage_gaps, max_out_of_pocket_exposure, claim_readiness, recommendation",
    )

    crew = Crew(agents=[agent], tasks=[task], verbose=False)
    result = crew.kickoff()

    return {"raw": str(result), "agent": "insurance"}
