"""
Fraud Agent
-----------
Detects anomalous transactions, potential scams, and identity
theft signals in financial transaction history.
"""

from crewai import Agent, Task, Crew
from langchain_openai import ChatOpenAI


llm = ChatOpenAI(model="gpt-4o", temperature=0.1)


def create_fraud_agent() -> Agent:
    return Agent(
        role="Financial Fraud Detection Specialist",
        goal=(
            "Identify anomalous transactions, recurring unauthorized charges, "
            "phishing-related payments, and patterns consistent with identity "
            "theft or account takeover."
        ),
        backstory=(
            "You are a former cybercrime investigator at a major financial "
            "institution's fraud division. You've seen every type of consumer "
            "financial fraud and can spot them in raw transaction data."
        ),
        llm=llm,
        verbose=True,
    )


def analyze_transactions(document_text: str) -> dict:
    """
    Run the fraud agent on transaction history text.
    Returns fraud risk score and flagged transactions.
    """
    agent = create_fraud_agent()

    task = Task(
        description=f"""
        Analyze the following transaction history for fraud indicators and return
        a JSON object with:
        - fraud_score: integer 0–100 (100 = high fraud likelihood)
        - flagged_transactions: list of suspicious entries with reason
        - fraud_type: most likely fraud type if detected (or "none")
        - estimated_exposure: estimated dollar amount at risk ($)
        - recommendation: one-sentence action item

        Transaction data:
        {document_text}
        """,
        agent=agent,
        expected_output="JSON with fraud_score, flagged_transactions, fraud_type, estimated_exposure, recommendation",
    )

    crew = Crew(agents=[agent], tasks=[task], verbose=False)
    result = crew.kickoff()

    return {"raw": str(result), "agent": "fraud"}
