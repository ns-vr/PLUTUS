"""
Health Agent
------------
Analyzes uploaded medical records and blood reports to produce a
health risk score and flag potential issues that could lead to
financial hardship.
"""

from crewai import Agent, Task, Crew
from langchain_openai import ChatOpenAI


llm = ChatOpenAI(model="gpt-4o", temperature=0.2)


def create_health_agent() -> Agent:
    return Agent(
        role="Medical Risk Analyst",
        goal=(
            "Analyze patient health records and blood reports to identify "
            "conditions that could escalate into expensive medical emergencies."
        ),
        backstory=(
            "You are a senior clinical data scientist who has worked with "
            "insurance actuaries for 15 years. You understand both the medical "
            "and financial implications of health conditions."
        ),
        llm=llm,
        verbose=True,
    )


def analyze_health_documents(document_text: str) -> dict:
    """
    Run the health agent on extracted document text.
    Returns a dict with risk_score (0–100) and findings list.
    """
    agent = create_health_agent()

    task = Task(
        description=f"""
        Analyze the following health document and return a JSON object with:
        - risk_score: integer 0–100 (100 = highest risk)
        - conditions: list of identified conditions
        - flags: list of conditions that may require expensive treatment
        - recommendation: one-sentence action item

        Document:
        {document_text}
        """,
        agent=agent,
        expected_output="JSON object with risk_score, conditions, flags, recommendation",
    )

    crew = Crew(agents=[agent], tasks=[task], verbose=False)
    result = crew.kickoff()

    # Parse result — in production, use a structured output parser
    return {"raw": str(result), "agent": "health"}
