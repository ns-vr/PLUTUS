"""
Finance Agent
-------------
Analyzes spending patterns, income, and liabilities to produce a
financial risk score and identify trajectory toward debt crisis.
"""

from crewai import Agent, Task, Crew
from langchain_openai import ChatOpenAI


llm = ChatOpenAI(model="gpt-4o", temperature=0.2)


def create_finance_agent() -> Agent:
    return Agent(
        role="Personal Finance Risk Analyst",
        goal=(
            "Analyze transaction history and financial statements to detect "
            "spending patterns, income volatility, and debt trajectories that "
            "signal an approaching financial crisis."
        ),
        backstory=(
            "You are a former fintech risk officer with 12 years of experience "
            "modeling consumer credit risk at a major bank. You can spot "
            "warning signs in financial data most people would miss."
        ),
        llm=llm,
        verbose=True,
    )


def analyze_finance_documents(document_text: str) -> dict:
    """
    Run the finance agent on extracted transaction/statement text.
    Returns a dict with risk_score (0–100) and findings.
    """
    agent = create_finance_agent()

    task = Task(
        description=f"""
        Analyze the following financial document and return a JSON object with:
        - risk_score: integer 0–100 (100 = highest risk)
        - debt_to_income_ratio: float (estimated)
        - spending_flags: list of concerning spending categories
        - savings_runway_months: estimated months of savings remaining
        - recommendation: one-sentence action item

        Document:
        {document_text}
        """,
        agent=agent,
        expected_output="JSON with risk_score, debt_to_income_ratio, spending_flags, savings_runway_months, recommendation",
    )

    crew = Crew(agents=[agent], tasks=[task], verbose=False)
    result = crew.kickoff()

    return {"raw": str(result), "agent": "finance"}
