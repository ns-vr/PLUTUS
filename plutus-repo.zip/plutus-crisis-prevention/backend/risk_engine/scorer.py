"""
Risk Engine — Scorer
--------------------
Aggregates outputs from all four agents into a unified
Crisis Probability Index (CPI) and risk category.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class AgentScores:
    health_score: float       # 0–100
    finance_score: float      # 0–100
    insurance_gap_score: float # 0–100
    fraud_score: float        # 0–100


@dataclass
class RiskReport:
    crisis_probability_index: float  # 0–100
    risk_category: str               # "low" | "moderate" | "high" | "critical"
    health_score: float
    finance_score: float
    insurance_gap_score: float
    fraud_score: float
    primary_risk: str
    summary: str


# Weights for each agent's contribution to the CPI
WEIGHTS = {
    "health":    0.30,
    "finance":   0.35,
    "insurance": 0.20,
    "fraud":     0.15,
}


def calculate_cpi(scores: AgentScores) -> RiskReport:
    """
    Calculate the Crisis Probability Index from the four agent scores.
    Returns a full RiskReport.
    """
    cpi = (
        scores.health_score       * WEIGHTS["health"]
        + scores.finance_score    * WEIGHTS["finance"]
        + scores.insurance_gap_score * WEIGHTS["insurance"]
        + scores.fraud_score      * WEIGHTS["fraud"]
    )

    category = _categorize(cpi)
    primary  = _primary_risk(scores)
    summary  = _build_summary(cpi, category, primary)

    return RiskReport(
        crisis_probability_index=round(cpi, 1),
        risk_category=category,
        health_score=scores.health_score,
        finance_score=scores.finance_score,
        insurance_gap_score=scores.insurance_gap_score,
        fraud_score=scores.fraud_score,
        primary_risk=primary,
        summary=summary,
    )


def _categorize(cpi: float) -> str:
    if cpi < 25:
        return "low"
    elif cpi < 50:
        return "moderate"
    elif cpi < 75:
        return "high"
    return "critical"


def _primary_risk(scores: AgentScores) -> str:
    worst = max(
        ("health",    scores.health_score),
        ("finance",   scores.finance_score),
        ("insurance", scores.insurance_gap_score),
        ("fraud",     scores.fraud_score),
        key=lambda x: x[1],
    )
    return worst[0]


def _build_summary(cpi: float, category: str, primary: str) -> str:
    labels = {
        "low":      "Your overall risk profile is healthy.",
        "moderate": "Some areas need attention before they escalate.",
        "high":     "Significant risk detected — action recommended within 30 days.",
        "critical": "Immediate action required across multiple risk domains.",
    }
    return (
        f"Crisis Probability Index: {cpi:.1f}/100 ({category.upper()}). "
        f"Primary concern: {primary} risk. "
        f"{labels[category]}"
    )
